# IPP Practical Files (Assignment 2 and Assignment 3)

| File | Contents |
|---|---|
| `Practical_File_1_IPP.ipynb` | 10 problems: statement, code, explanation, real output |
| `Practical_File_2_IPP.ipynb` | 6 problems: statement, code, output, short observations (no code explanation) |
| `IPP_Practical_File_*_Kushagra_Mishra.docx` | Word versions (code, output, figures, explanation/observations) ready to submit |
| `*.html` | Same notebooks with outputs, easy to open in a browser, print or save as PDF |
| `*.jpg / *.png` | Sample images used by the code (keep them in the same folder as the notebooks) |

## Run (PyCharm / VS Code / terminal)
```
pip install -r requirements.txt
jupyter notebook          # then open a notebook and choose Run All
```
In PyCharm you can also open the `.ipynb` file directly and press "Run All Cells".
Google Colab works too: upload the notebook and the image files, then Run all.

## Notes
* File 1 starts with a "Setup" cell so that `cv2.imshow()` / `Image.show()` appear inline in Jupyter. If you copy the code into a normal `.py` script, skip that cell; the problem code itself is unchanged.
* `car.jpg` is a stand-in photo (a building) because no car image was supplied. Replace any sample image with your own file of the same name and re-run.
* File 2 images: outdoor scene `building.jpg`; `camera`, `page`, `brick`, `grass`, `gravel` come bundled with scikit-image; `leaf_disease.jpg` is a PlantVillage potato early-blight leaf. Problem 3 also uses a synthetic poster that is generated in the code.
* Save as PDF for submission: open the `.html` in a browser and Print -> Save as PDF.
